FANGSCAPE - an old-school vampire RPG
a ZotixSoft game

HOW TO PLAY
  1. Unzip the whole folder somewhere (keep all the files together).
  2. Double-click Fangscape.exe.
  3. If Windows says "Windows protected your PC", click "More info" -> "Run anyway".
     (The game isn't code-signed, like most small indie games.)

CONTROLS
  Left click ........... walk / attack / talk / use (the default action)
  Right click .......... options menu (Feed-on, Attack, Examine, Walk here...)
  Arrow keys / middle mouse drag ... rotate the camera
  Mouse wheel .......... zoom
  R .................... toggle run
  Side panel tabs ...... Skills, Combat, Items, Quests, Gear, Spellbook, Quick Setup, Incantations, Music

TIPS
  - The sun weakens you outdoors (-25% accuracy and damage). Hunt at night, or fight indoors.
  - Feed on villagers for blood. Blood heals you fast. Hunters will notice.
  - Igor in the castle has a short tutorial and your first quest.
  - The Quick Setup tab (crossed sword + staff) hands you a Warrior, Ranger, Mage or Hybrid kit for your levels.
  - Turn on "ADMIN PANEL" in the main menu if you just want to mess around: press F1 in game for
    spawning items, max stats, god mode and teleports. F5 gives a dev chest.

YOUR SAVE
  The game autosaves every minute and when you quit, to save.txt in this folder.
  Delete save.txt to start over.

CREDITS
  Game & music: ZotixSoft
  Made with raylib (raylib.com)
