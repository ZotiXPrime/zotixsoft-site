BRUISE - your premium is about to go up
A ZotixSoft game by Arvin Setareh  -  zotixsoft.com

HOW TO PLAY
Unzip the whole folder somewhere, then double-click Bruise.exe.
Windows may show a SmartScreen warning because the game is unsigned:
click "More info" then "Run anyway".

CONTROLS
WASD ............ move
SHIFT ........... sprint (through walls)
HOLD SPACE ...... super leap (tier 3+: hold in the air to FLY)
LMB ............. punch / in the air: dive-bomb where you aim
RMB ............. thunder-clap
HOLD R / MMB .... The Big Deductible beam (aim at the floor to fly)
E / F ........... grab a car / rip it into gear
Q ............... rage
TAB ............. map
C comic shading   M mute   P pink   H help   F11 fullscreen   ESC pause

CAREER: ten insurance claims, up to 3 stars each.
POWER TIERS: every dollar of damage levels you up, from Civil Nuisance to Heat Death.

Your progress saves to bruise_save.txt next to the game.
